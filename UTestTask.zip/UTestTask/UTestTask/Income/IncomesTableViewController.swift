//
//  IncomesTableViewController.swift
//  UTestTask
//
//  Created by Михаил on 06.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import UIKit

class IncomesTableViewController: UITableViewController {

	var category: IncomeCategory!
	var incomes = [Income]()
	
	override func viewWillAppear(_ animated: Bool) {
		super.viewWillAppear(animated)
		
		incomes = CoreDataManager.shared.fetchIncomesByCategory(category)
		
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		tableView.register(IncomeTableViewCell.self, forCellReuseIdentifier: "incomeCellId")
		
		navigationItem.title  = "\(category.name ?? "Доходы")"
		
		let backItem = UIBarButtonItem()
		backItem.title = " "
		navigationItem.backBarButtonItem = backItem
		
		navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(handleAddIncome))
		navigationController?.navigationBar.setBackgroundImage(UIImage(imageLiteralResourceName: "NavBarBackOrange"), for: .default)
		
	}
	
	@objc private func handleAddIncome(){
		
		let createIncomeVC = CreateOrEditIncomeViewController()
		createIncomeVC.category = category
		createIncomeVC.delegate = self
		navigationController?.pushViewController(createIncomeVC, animated: true)
	}
	
}

extension IncomesTableViewController{
	
	override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return incomes.count
	}
		
	override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		let cell = tableView.dequeueReusableCell(withIdentifier: "incomeCellId", for: indexPath) as! IncomeTableViewCell
		
		let income = incomes[indexPath.row]
		cell.income = income
		return cell
	}
}

extension IncomesTableViewController: CreateIncomeControllerDelegate{
	
	func didEditIncome(_ income: Income) {
		let row = incomes.index(of: income)
		let reloadIndexPath = IndexPath(row: row!, section: 0)
		tableView.reloadRows(at: [reloadIndexPath], with: .middle)
	}
	
	func didAddIncome(_ income: Income) {
		incomes.append(income)
		let newIndexPath = IndexPath(row: incomes.count - 1, section: 0)
		tableView.insertRows(at: [newIndexPath], with: .automatic)
	}
	
	
}
