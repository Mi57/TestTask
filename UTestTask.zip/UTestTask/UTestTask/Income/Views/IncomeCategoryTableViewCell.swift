//
//  IncomeCategoryTableViewCell.swift
//  UTestTask
//
//  Created by Михаил on 06.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import UIKit

class IncomeCategoryTableViewCell: UITableViewCell {

	var category: IncomeCategory?{
		didSet{
			nameLabel.text = category?.name
			descriptionLabel.text = category?.categoryDescription
		}
	}
	
	let nameLabel: UILabel = {
		let label = UILabel()
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	let descriptionLabel: UILabel = {
		let label  = UILabel()
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	override func awakeFromNib() {
		super.awakeFromNib()
	}
	
	override func setSelected(_ selected: Bool, animated: Bool) {
		super.setSelected(selected, animated: animated)
		
	}
	
	override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
		super.init(style: style, reuseIdentifier: reuseIdentifier)
		
		
		setupUI()
	}
	
	private func setupUI(){
		
		addSubview(nameLabel)
		nameLabel.topAnchor.constraint(equalTo: topAnchor, constant: 8).isActive = true
		nameLabel.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
		nameLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: 8).isActive = true
		
		addSubview(descriptionLabel)
		descriptionLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 8).isActive = true
		descriptionLabel.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
		descriptionLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: 8).isActive = true
		descriptionLabel.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
	}
	
	required init?(coder aDecoder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}

}
