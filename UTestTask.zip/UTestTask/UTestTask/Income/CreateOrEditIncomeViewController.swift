//
//  CreateOrEditIncomeViewController.swift
//  UTestTask
//
//  Created by Михаил on 06.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import UIKit
import CoreData

protocol CreateIncomeControllerDelegate: class {
	func didAddIncome(_ income: Income)
	func didEditIncome(_ income: Income)
}

class CreateOrEditIncomeViewController: UIViewController {

	weak var delegate: CreateIncomeControllerDelegate?
	var income: Income?
	var category: IncomeCategory!
	
	let nameLabel: UILabel = {
		let label = UILabel()
		label.text = "Откуда деньги:"
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	let nameTextField: UITextField = {
		let textField = UITextField()
		textField.borderStyle = .roundedRect
		textField.placeholder = "Например: Зарплата"
		textField.translatesAutoresizingMaskIntoConstraints = false
		return textField
	}()
	
	let descriptionLabel: UILabel = {
		let label = UILabel()
		label.text = "Описание:"
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	let descriptionTextField: UITextField = {
		let textField = UITextField()
		textField.borderStyle = .roundedRect
		textField.placeholder = "Краткое описание"
		textField.translatesAutoresizingMaskIntoConstraints = false
		return textField
	}()
	
	let amountTextField: UITextField = {
		let textField = UITextField()
		textField.borderStyle = .roundedRect
		textField.keyboardType = .decimalPad
		textField.placeholder = "Сумма"
		textField.translatesAutoresizingMaskIntoConstraints = false
		return textField
	}()
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		view.backgroundColor = .white
		setupUI()
		setupRightButton()
	}
	
	private func setupRightButton(){
		
		navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(createIncome))
	}
	
	@objc private func createIncome() {
		
		let context = CoreDataManager.shared.persistentContainer.viewContext
		
		let income = NSEntityDescription.insertNewObject(forEntityName: "Income", into: context)
		
		let amount = Decimal(string: amountTextField.text ?? "0")
		income.setValue(nameTextField.text, forKey: "name")
		income.setValue(descriptionTextField.text, forKey: "incomeDescription")
		income.setValue(category, forKey: "category")
		income.setValue(amount, forKey: "amount")
		do {
			try context.save()
			
			navigationController?.popViewController(animated: true)
			self.delegate?.didAddIncome(income as! Income)
			
		} catch let saveErr {
			print("Failed to save category:", saveErr)
		}
	}
	
	private func setupUI(){
		
		view.addSubview(nameLabel)
		nameLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 16).isActive = true
		nameLabel.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		nameLabel.widthAnchor.constraint(equalToConstant: 200).isActive = true
		nameLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
		
		view.addSubview(nameTextField)
		nameTextField.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		nameTextField.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -16).isActive = true
		nameTextField.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 6).isActive = true
		
		view.addSubview(descriptionLabel)
		descriptionLabel.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 16).isActive = true
		descriptionLabel.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		descriptionLabel.widthAnchor.constraint(equalToConstant: 200).isActive = true
		descriptionLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
		
		view.addSubview(descriptionTextField)
		descriptionTextField.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		descriptionTextField.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -16).isActive = true
		descriptionTextField.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor , constant: 8).isActive = true
		
		view.addSubview(amountTextField)
		amountTextField.topAnchor.constraint(equalTo: descriptionTextField.bottomAnchor, constant: 16).isActive = true
		amountTextField.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		amountTextField.widthAnchor.constraint(equalToConstant: 200).isActive = true
		amountTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
	}

}
