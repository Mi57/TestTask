//
//  CreateOrEditIncomeCategoryViewController.swift
//  UTestTask
//
//  Created by Михаил on 06.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import UIKit
import CoreData

protocol CreateIncomeCategoryControllerDelegate: class {
	func didAddIncomeCategory(incomeCategory: IncomeCategory)
	func didEditIncomeCategory(incomeCategory: IncomeCategory)
}

class CreateOrEditIncomeCategoryViewController: UIViewController {

	weak var delegate: CreateIncomeCategoryControllerDelegate?
	var IncomeCategory: IncomeCategory?
	
	let nameLabel: UILabel = {
		let label = UILabel()
		label.text = "Категория:"
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	let nameTextField: UITextField = {
		let textField = UITextField()
		textField.borderStyle = .roundedRect
		textField.placeholder = "Название категории"
		textField.translatesAutoresizingMaskIntoConstraints = false
		return textField
	}()
	
	let descriptionLabel: UILabel = {
		let label = UILabel()
		label.text = "Описание категории:"
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	let descriptionTextField: UITextField = {
		let textField = UITextField()
		textField.borderStyle = .roundedRect
		textField.placeholder = "Краткое описание категории"
		textField.translatesAutoresizingMaskIntoConstraints = false
		return textField
	}()
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		navigationItem.title = "Создание категории"
		navigationController?.navigationBar.barTintColor = .white
		view.backgroundColor = .white
		
		setupUI()
		setupRightButton()
	}
	
	private func setupRightButton(){
		
		navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(handleCreateCategory))
	}
	
	@objc private func handleCreateCategory(){
		
		if IncomeCategory == nil {
			createCategory()
		}
	}
	
	private func createCategory() {
		
		let context = CoreDataManager.shared.persistentContainer.viewContext
		
		let category = NSEntityDescription.insertNewObject(forEntityName: "IncomeCategory", into: context)
		
		category.setValue(nameTextField.text, forKey: "name")
		category.setValue(descriptionTextField.text, forKey: "categoryDescription")
		
		do {
			try context.save()
			
			self.delegate?.didAddIncomeCategory(incomeCategory: category as! IncomeCategory)
			navigationController?.popViewController(animated: true)
			
		} catch let saveErr {
			print("Failed to save category:", saveErr)
		}
	}
	
	private func setupUI(){
		
		view.addSubview(nameLabel)
		nameLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 16).isActive = true
		nameLabel.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		nameLabel.widthAnchor.constraint(equalToConstant: 100).isActive = true
		nameLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
		
		view.addSubview(nameTextField)
		nameTextField.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		nameTextField.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -16).isActive = true
		nameTextField.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 6).isActive = true
		
		view.addSubview(descriptionLabel)
		descriptionLabel.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 16).isActive = true
		descriptionLabel.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		descriptionLabel.widthAnchor.constraint(equalToConstant: 200).isActive = true
		descriptionLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
		
		view.addSubview(descriptionTextField)
		descriptionTextField.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
		descriptionTextField.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -16).isActive = true
		descriptionTextField.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 6).isActive = true
		
	}
	

}
