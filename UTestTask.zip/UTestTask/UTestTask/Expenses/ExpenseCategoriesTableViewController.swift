//
//  ExpenseCategoriesTableViewController.swift
//  UTestTask
//
//  Created by Михаил on 03.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import UIKit

class ExpenseCategoriesTableViewController: UITableViewController {
	
	var categories = [ExpenseCategory]()
	var total: Decimal {
		let totalAllCategories = categories.reduce(0) { (result, category) -> Decimal in
			
			if let expenses = category.expenses{
				return result + expenses.reduce(0, { (result, expense) -> Decimal in
					if let expense = expense as? Expense{
						return result + (expense.amount?.decimalValue ?? 0)
					}
					return result
				})
			}
			return result
		}
		return totalAllCategories
	}
	
	override func viewWillAppear(_ animated: Bool) {
		super.viewWillAppear(animated)
		
		categories = CoreDataManager.shared.fetchExpenseCategories()
		navigationItem.title  = "Итого: \(total) р."
		tableView.reloadData()
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()

		tableView.estimatedRowHeight = 60
		tableView.rowHeight = 60
		tableView.register(ExpenseCategoryTableViewCell.self, forCellReuseIdentifier: "cellId")
		
		let backItem = UIBarButtonItem()
		backItem.title = " "
		navigationItem.backBarButtonItem = backItem
		
		navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(handleAddExpenseCategory))
		navigationController?.navigationBar.setBackgroundImage(UIImage(imageLiteralResourceName: "NavBarBackBlue"), for: .default)
		
	}

	@objc private func handleAddExpenseCategory(){
		
		let createCategoryVC = CreateOrEditExpenseCategoryViewController()
		createCategoryVC.delegate = self
		navigationController?.pushViewController(createCategoryVC, animated: true)
	}

}

extension ExpenseCategoriesTableViewController {
	
	override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

		let category = categories[indexPath.row]
		let expensesTVC = ExpensesTableViewController()
		expensesTVC.category = category
		navigationController?.pushViewController(expensesTVC, animated: true)
	}
	
	override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {

		let deleteAction = UITableViewRowAction(style: .destructive, title: "Delete") { (_, indexPath) in
			let category = self.categories[indexPath.row]

			self.categories.remove(at: indexPath.row)
			self.tableView.deleteRows(at: [indexPath], with: .automatic)

			let context = CoreDataManager.shared.persistentContainer.viewContext

			context.delete(category)

			do {
				try context.save()
			} catch let saveErr {
				print("Failed to delete category:", saveErr)
			}
		}
		deleteAction.backgroundColor = UIColor.red

		return [deleteAction]
	}
	
	override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		let cell = tableView.dequeueReusableCell(withIdentifier: "cellId", for: indexPath) as! ExpenseCategoryTableViewCell
		let category = categories[indexPath.row]
		cell.category = category
		return cell
	}
	
	override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return categories.count
	}
	
}

extension ExpenseCategoriesTableViewController: CreateExpenseCategoryControllerDelegate {
	
	func didEditExpenseCategory(expenseCategory: ExpenseCategory) {
		let row = categories.index(of: expenseCategory)
		let reloadIndexPath = IndexPath(row: row!, section: 0)
		tableView.reloadRows(at: [reloadIndexPath], with: .middle)
	}
	
	
	func didAddExpenseCategory(expenseCategory: ExpenseCategory) {
		categories.append(expenseCategory)
		let newIndexPath = IndexPath(row: categories.count - 1, section: 0)
		tableView.insertRows(at: [newIndexPath], with: .automatic)
	}
	
}

