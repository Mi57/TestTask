//
//  ExpenseTableViewCell.swift
//  UTestTask
//
//  Created by Михаил on 05.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import UIKit

class ExpenseTableViewCell: UITableViewCell {

	var expense: Expense?{
		didSet{
			nameLabel.text = expense?.name
			descriptionLabel.text = expense?.expenseDescription
			amountLabel.text = "\(expense?.amount ?? 0)"
		}
	}
	
	let nameLabel: UILabel = {
		let label = UILabel()
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	let descriptionLabel: UILabel = {
		let label  = UILabel()
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	let amountLabel: UILabel = {
		let label = UILabel()
		label.translatesAutoresizingMaskIntoConstraints = false
		return label
	}()
	
	override func awakeFromNib() {
		super.awakeFromNib()
	}
	
	override func setSelected(_ selected: Bool, animated: Bool) {
		super.setSelected(selected, animated: animated)
		
	}
	
	override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
		super.init(style: style, reuseIdentifier: reuseIdentifier)
				
		setupUI()
	}
	
	private func setupUI(){
		
		addSubview(nameLabel)
		nameLabel.topAnchor.constraint(equalTo: topAnchor, constant: 8).isActive = true
		nameLabel.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
		nameLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: 8).isActive = true
		
		addSubview(descriptionLabel)
		descriptionLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 8).isActive = true
		descriptionLabel.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
		descriptionLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: 8).isActive = true
		
		addSubview(amountLabel)
		amountLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 8).isActive = true
		amountLabel.leftAnchor.constraint(equalTo: leftAnchor, constant: 16).isActive = true
		amountLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: 8).isActive = true
		amountLabel.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
	}
	
	required init?(coder aDecoder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}

}
