//
//  ExpensesTableViewController.swift
//  UTestTask
//
//  Created by Михаил on 05.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import UIKit

class ExpensesTableViewController: UITableViewController {

	var category: ExpenseCategory!
	var expenses = [Expense]()
	
	override func viewWillAppear(_ animated: Bool) {
		super.viewWillAppear(animated)
		
		expenses = CoreDataManager.shared.fetchExpensesByCategory(category)
		
	}
	
    override func viewDidLoad() {
        super.viewDidLoad()

		tableView.register(ExpenseTableViewCell.self, forCellReuseIdentifier: "expenseCellId")
		
		navigationItem.title  = "\(category.name ?? "Расходы")"
		let backItem = UIBarButtonItem()
		backItem.title = " "
		navigationItem.backBarButtonItem = backItem
		navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(handleAddExpense))
		navigationController?.navigationBar.setBackgroundImage(UIImage(imageLiteralResourceName: "NavBarBackBlue"), for: .default)
        
    }
	
	@objc private func handleAddExpense(){
		
		let createExpenseVC = CreateOrEditExpenseViewController()
		createExpenseVC.category = category
		createExpenseVC.delegate = self
		navigationController?.pushViewController(createExpenseVC, animated: true)
	}

}

 // MARK: - Table view data source
extension ExpensesTableViewController{
	
	override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return expenses.count
	}
	
	
	override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		let cell = tableView.dequeueReusableCell(withIdentifier: "expenseCellId", for: indexPath) as! ExpenseTableViewCell
		
		let expense = expenses[indexPath.row]
		cell.expense = expense
		return cell
	}
}

extension ExpensesTableViewController: CreateExpenseControllerDelegate{
	
	func didEditExpense(_ expense: Expense) {
		let row = expenses.index(of: expense)
		let reloadIndexPath = IndexPath(row: row!, section: 0)
		tableView.reloadRows(at: [reloadIndexPath], with: .middle)
	}
	
	func didAddExpense(_ expense: Expense) {
		expenses.append(expense)
		let newIndexPath = IndexPath(row: expenses.count - 1, section: 0)
		tableView.insertRows(at: [newIndexPath], with: .automatic)
	}
	
	
}
