//
//  MainTabBarController.swift
//  UTestTask
//
//  Created by Михаил on 03.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import UIKit

class MainTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
		
		let incomeImage = UIImage(imageLiteralResourceName: "Income")
		let expenseImage = UIImage(imageLiteralResourceName: "Expense")
		
		viewControllers = [createNavController(with: IncomeCategoriesTableViewController(), title: "Доходы", image: incomeImage),
						   createNavController(with: ExpenseCategoriesTableViewController(), title: "Расходы", image: expenseImage)]
    }
    
	private func createNavController(with rootViewController: UIViewController, title: String, image: UIImage) -> UIViewController{
		
		
		let navController = UINavigationController(rootViewController: rootViewController)
		navController.tabBarItem.title = title
		navController.tabBarItem.image = image
		navController.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]

		return navController
	}

}
