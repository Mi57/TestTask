//
//  CoreDataManager.swift
//  UTestTask
//
//  Created by Михаил on 04.11.2018.
//  Copyright © 2018 M57. All rights reserved.
//

import CoreData

struct CoreDataManager {
	
	static let shared = CoreDataManager()
	
	let persistentContainer: NSPersistentContainer = {
		let container = NSPersistentContainer(name: "UTestTaskModel")
		container.loadPersistentStores { (storeDescription, err) in
			if let err = err {
				fatalError("Loading of store failed: \(err)")
			}
		}
		return container
	}()

	func fetchExpenseCategories() -> [ExpenseCategory] {
		let context = persistentContainer.viewContext
		
		let fetchRequest = NSFetchRequest<ExpenseCategory>(entityName: "ExpenseCategory")
		do {
			let expenseCategories = try context.fetch(fetchRequest)
			return expenseCategories
		} catch let fetchErr {
			print("Failed to fetch expense categories:", fetchErr)
			return []
		}
	}
	
	func fetchIncomeCategories() -> [IncomeCategory] {
		let context = persistentContainer.viewContext
		
		let fetchRequest = NSFetchRequest<IncomeCategory>(entityName: "IncomeCategory")
		do {
			let incomeCategories = try context.fetch(fetchRequest)
			return incomeCategories
		} catch let fetchErr {
			print("Failed to fetch income categories:", fetchErr)
			return []
		}
	}
	
	func fetchExpensesByCategory(_ category: ExpenseCategory) -> [Expense] {
		let context = persistentContainer.viewContext
		
		let fetchRequest = NSFetchRequest<Expense>(entityName: "Expense")
		fetchRequest.predicate = NSPredicate(format: "%K == %@", #keyPath(Expense.category), category)
		do {
			let expenses = try context.fetch(fetchRequest)
			return expenses
		} catch let fetchErr {
			print("Failed to fetch expenses:", fetchErr)
			return []
		}
	}
	
	func fetchIncomesByCategory(_ category: IncomeCategory) -> [Income] {
		let context = persistentContainer.viewContext
		
		let fetchRequest = NSFetchRequest<Income>(entityName: "Income")
		fetchRequest.predicate = NSPredicate(format: "%K == %@", #keyPath(Income.category), category)
		do {
			let incomes = try context.fetch(fetchRequest)
			return incomes
		} catch let fetchErr {
			print("Failed to fetch incomes:", fetchErr)
			return []
		}
	}
}
